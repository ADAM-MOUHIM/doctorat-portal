package com.micro.serviceauth.enums;

public enum Role {
    SUPERUSER,
    ADMIN,
    DIRECTEUR,   // Encadrant
    DOCTORANT
}
