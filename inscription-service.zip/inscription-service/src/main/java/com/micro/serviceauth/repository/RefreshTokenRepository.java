package com.micro.serviceauth.repository;

import com.micro.serviceauth.entity.RefreshToken;
import com.micro.serviceauth.enums.RefreshTokenStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Accès aux refresh tokens (par tokenHash, compte, famille).
 */
public interface RefreshTokenRepository extends JpaRepository<RefreshToken, UUID> {

    Optional<RefreshToken> findByTokenHash(String tokenHash);

    List<RefreshToken> findAllByAccount_IdAndStatus(UUID accountId, RefreshTokenStatus status);

    List<RefreshToken> findAllByFamilyId(UUID familyId);
}
