package com.micro.serviceauth.enums;

public enum AccountStatus {
    PENDING,
    ACTIVE,
    SUSPENDED,
    REJECTED
}
